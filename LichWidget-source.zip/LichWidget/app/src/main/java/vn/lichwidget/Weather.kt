package vn.lichwidget

import org.json.JSONObject
import kotlin.math.roundToInt

class Weather(
    val temp: Int,
    val humidity: Int,
    val code: Int,
    val dCode: IntArray,
    val dMax: IntArray,
    val dMin: IntArray,
    val dPop: IntArray
) {
    companion object {
        fun parse(json: String): Weather? {
            return try {
                val o = JSONObject(json)
                val cur = o.getJSONObject("current")
                val d = o.getJSONObject("daily")
                val codes = d.getJSONArray("weather_code")
                val max = d.getJSONArray("temperature_2m_max")
                val min = d.getJSONArray("temperature_2m_min")
                val pop = d.getJSONArray("precipitation_probability_max")
                val n = 3
                Weather(
                    cur.getDouble("temperature_2m").roundToInt(),
                    cur.optInt("relative_humidity_2m", 0),
                    cur.optInt("weather_code", 3),
                    IntArray(n) { codes.optInt(it, 3) },
                    IntArray(n) { max.getDouble(it).roundToInt() },
                    IntArray(n) { min.getDouble(it).roundToInt() },
                    IntArray(n) { pop.optInt(it, 0) }
                )
            } catch (e: Exception) {
                null
            }
        }

        fun describe(code: Int): String = when (code) {
            0 -> "Trời quang"
            1 -> "Ít mây"
            2 -> "Có mây"
            3 -> "Nhiều mây"
            45, 48 -> "Sương mù"
            51, 53, 55, 56, 57 -> "Mưa phùn"
            61, 63, 65, 66, 67 -> "Có mưa"
            71, 73, 75, 77, 85, 86 -> "Có tuyết"
            80, 81, 82 -> "Mưa rào"
            95, 96, 99 -> "Có dông"
            else -> "Nhiều mây"
        }

        fun icon(code: Int): Int = when (code) {
            0 -> R.drawable.ic_w_sun
            1, 2 -> R.drawable.ic_w_partly
            3 -> R.drawable.ic_w_cloud
            45, 48, 71, 73, 75, 77, 85, 86 -> R.drawable.ic_w_fog
            51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82 -> R.drawable.ic_w_rain
            95, 96, 99 -> R.drawable.ic_w_storm
            else -> R.drawable.ic_w_cloud
        }
    }
}
