package vn.lichwidget

import android.graphics.Color

class WStyle(
    val key: String,
    val label: String,
    val desc: String,
    val layout: Int,
    val rootBg: Int,
    val bodyBg: Int,
    val edge: Boolean,
    val pill: Int,
    val chip: Int,
    val today: Int,
    colors: Array<String>
) {
    val primary = Color.parseColor(colors[0])
    val secondary = Color.parseColor(colors[1])
    val tertiary = Color.parseColor(colors[2])
    val weekLabel = Color.parseColor(colors[3])
    val sunday = Color.parseColor(colors[4])
    val accent = Color.parseColor(colors[5])
    val battery = Color.parseColor(colors[6])
    val todayText = Color.parseColor(colors[7])
    val todaySub = Color.parseColor(colors[8])
}

object Styles {
    private val GLASS = arrayOf("#FFFFFF", "#E6FFFFFF", "#99FFFFFF", "#CCFFFFFF", "#FF9A9E", "#9CCBFF", "#9BF0B8", "#FFFFFF", "#FFE0E0")
    private val INK = arrayOf("#14161C", "#4A4F57", "#9AA0A8", "#7A7F87", "#E5484D", "#2F80D0", "#2E9E57", "#FFFFFF", "#FFE0E0")
    private val DARK = arrayOf("#F2F4F7", "#D9E0E8", "#8E98A4", "#AAB3BF", "#FF8A8F", "#8CC8FF", "#7DE0A0", "#FFFFFF", "#FFE0E0")
    private val SUNSET = arrayOf("#FFFFFF", "#F2FFFFFF", "#CCFFFFFF", "#E6FFFFFF", "#FFF3A0", "#CFE8FF", "#FFFFFF", "#D6336C", "#E8789A")

    val all: List<WStyle> = listOf(
        WStyle("glass", "Kính lỏng", "Trong suốt, viền sáng, chữ trắng",
            R.layout.widget_lich, R.drawable.widget_bg, 0, false,
            R.drawable.pill_dark, R.drawable.chip_bg, R.drawable.today_bg, GLASS),
        WStyle("paper", "Giấy rách xếp chồng", "Giấy kem, mép rách, nhiều lớp giấy",
            R.layout.widget_lich_flat, 0, R.drawable.paper_body, true,
            R.drawable.pill_ink, R.drawable.chip_paper, R.drawable.today_paper, INK),
        WStyle("light", "Thẻ sáng tối giản", "Thẻ trắng sạch, chữ đen",
            R.layout.widget_lich_flat, R.drawable.card_light, 0, false,
            R.drawable.pill_ink, R.drawable.chip_paper, R.drawable.today_paper, INK),
        WStyle("dark", "Đêm", "Thẻ tối, hợp màn hình AMOLED",
            R.layout.widget_lich_flat, R.drawable.card_dark, 0, false,
            R.drawable.pill_dark, R.drawable.chip_bg, R.drawable.today_bg, DARK),
        WStyle("sunset", "Hoàng hôn", "Nền chuyển màu hồng tím",
            R.layout.widget_lich_flat, R.drawable.sunset_bg, 0, false,
            R.drawable.pill_dark, R.drawable.chip_bg, R.drawable.today_white, SUNSET)
    )

    fun get(key: String?): WStyle = all.firstOrNull { it.key == key } ?: all[0]
}
