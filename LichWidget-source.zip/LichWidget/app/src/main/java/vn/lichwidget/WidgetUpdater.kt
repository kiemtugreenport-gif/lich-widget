package vn.lichwidget

import android.Manifest
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.BatteryManager
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.View
import android.widget.RemoteViews
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.Locale

object WidgetUpdater {
    const val ACTION_REFRESH = "vn.lichwidget.REFRESH"

    const val PREFS = "lich_widget"
    private const val DEFAULT_LAT = 20.9719   // Hà Đông, Hà Nội
    private const val DEFAULT_LON = 105.7770
    private const val DEFAULT_NAME = "Hà Đông"
    private const val MIN_AGE_MS = 20 * 60 * 1000L

    private val WD_FULL = arrayOf("Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy")

    /** Gọi trên luồng nền. */
    fun update(ctx: Context, force: Boolean = false) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, LichWidgetProvider::class.java))
        if (ids.isEmpty()) return
        render(ctx, mgr, ids)
        if (fetch(ctx, force)) render(ctx, mgr, ids)
    }

    // ---------------- Dữ liệu ----------------

    private fun hasLocationPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Lấy vị trí GPS/mạng gần nhất; nếu không có thì dùng vị trí đã lưu, cuối cùng là Hà Đông. */
    private fun currentLocation(ctx: Context): Pair<Double, Double> {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        var best: Location? = null
        if (hasLocationPermission(ctx)) {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            for (p in listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
                try {
                    val l = lm.getLastKnownLocation(p)
                    if (l != null && (best == null || l.time > best.time)) best = l
                } catch (e: Exception) {
                }
            }
        }
        if (best != null) {
            sp.edit().putString("lat", best.latitude.toString()).putString("lon", best.longitude.toString()).apply()
            return Pair(best.latitude, best.longitude)
        }
        val lat = sp.getString("lat", null)?.toDoubleOrNull()
        val lon = sp.getString("lon", null)?.toDoubleOrNull()
        if (lat != null && lon != null) return Pair(lat, lon)
        return Pair(DEFAULT_LAT, DEFAULT_LON)
    }

    private fun cleanName(raw: String): String {
        var s = raw.trim()
        for (p in listOf("Quận ", "Huyện ", "Thị xã ", "Thành phố ", "Phường ", "Xã ", "Thị trấn ")) {
            if (s.startsWith(p)) s = s.removePrefix(p)
        }
        for (x in listOf(" District", " City", " Ward", " Town")) {
            if (s.endsWith(x)) s = s.removeSuffix(x)
        }
        return s.trim()
    }

    @Suppress("DEPRECATION")
    private fun placeName(ctx: Context, lat: Double, lon: Double): String? {
        if (!Geocoder.isPresent()) return null
        return try {
            val list = Geocoder(ctx, Locale("vi", "VN")).getFromLocation(lat, lon, 1)
            val a = list?.firstOrNull() ?: return null
            val raw = a.subAdminArea ?: a.locality ?: a.subLocality ?: a.adminArea ?: return null
            cleanName(raw)
        } catch (e: Exception) {
            null
        }
    }

    private fun httpGet(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        return try {
            c.connectTimeout = 6000
            c.readTimeout = 6000
            if (c.responseCode != 200) null else c.inputStream.bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            null
        } finally {
            c.disconnect()
        }
    }

    /** @return true nếu có dữ liệu mới cần vẽ lại */
    private fun fetch(ctx: Context, force: Boolean): Boolean {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val (lat, lon) = currentLocation(ctx)
        val key = String.format(Locale.US, "%.2f,%.2f", lat, lon)
        val keyChanged = sp.getString("name_key", null) != key
        val age = System.currentTimeMillis() - sp.getLong("weather_ts", 0L)
        if (!force && !keyChanged && age < MIN_AGE_MS) return false

        var changed = false
        if (keyChanged) {
            val usingDefault = !hasLocationPermission(ctx) && sp.getString("lat", null) == null
            val name = if (usingDefault) DEFAULT_NAME else (placeName(ctx, lat, lon) ?: "Vị trí hiện tại")
            sp.edit().putString("name_key", key).putString("name", name).apply()
            changed = true
        }
        val url = String.format(
            Locale.US,
            "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f" +
                "&current=temperature_2m,relative_humidity_2m,weather_code" +
                "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                "&timezone=auto&forecast_days=3",
            lat, lon
        )
        val body = httpGet(url)
        if (body != null && Weather.parse(body) != null) {
            sp.edit().putString("weather_json", body).putLong("weather_ts", System.currentTimeMillis()).apply()
            changed = true
        }
        return changed
    }

    // ---------------- Giao diện ----------------

    private fun vid(ctx: Context, name: String): Int = ctx.resources.getIdentifier(name, "id", ctx.packageName)

    private fun render(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val st = Styles.get(sp.getString("style", "glass"))
        val rv = RemoteViews(ctx.packageName, st.layout)
        val now = Calendar.getInstance()
        val dp = ctx.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()

        // Kiểu giao diện
        rv.setInt(R.id.root, "setBackgroundResource", st.rootBg)
        rv.setInt(R.id.body, "setBackgroundResource", st.bodyBg)
        rv.setViewPadding(R.id.body, px(14), px(14), px(14), px(14))
        rv.setViewVisibility(R.id.edge, if (st.edge) View.VISIBLE else View.GONE)
        rv.setInt(R.id.lunar, "setBackgroundResource", st.pill)
        rv.setViewPadding(R.id.lunar, px(10), px(4), px(10), px(4))
        rv.setInt(R.id.battery, "setBackgroundResource", st.chip)
        rv.setViewPadding(R.id.battery, px(8), px(3), px(8), px(3))
        rv.setTextColor(R.id.greeting, st.secondary)
        rv.setTextColor(R.id.clock, st.primary)
        rv.setTextColor(R.id.date, st.primary)
        rv.setTextColor(R.id.lunar, Color.WHITE)
        rv.setTextColor(R.id.w_temp, st.primary)
        rv.setTextColor(R.id.w_cond, st.primary)
        rv.setTextColor(R.id.w_loc, st.secondary)
        rv.setTextColor(R.id.battery, st.battery)

        // Lời chào
        val hour = now.get(Calendar.HOUR_OF_DAY)
        val greeting = when {
            hour < 5 -> "Chào buổi đêm"
            hour < 11 -> "Chào buổi sáng"
            hour < 13 -> "Chào buổi trưa"
            hour < 18 -> "Chào buổi chiều"
            else -> "Chào buổi tối"
        }
        rv.setTextViewText(R.id.greeting, greeting)

        // Ngày dương + âm
        val dow = now.get(Calendar.DAY_OF_WEEK)
        val d = now.get(Calendar.DAY_OF_MONTH)
        val m = now.get(Calendar.MONTH) + 1
        val y = now.get(Calendar.YEAR)
        rv.setTextViewText(R.id.date, "${WD_FULL[dow - 1]}, $d Thg $m")
        val l = LunarCalendar.convert(d, m, y)
        val leapTxt = if (l.leap) " nhuận" else ""
        rv.setTextViewText(R.id.lunar, "${l.day}/${l.month}$leapTxt ÂL • ${LunarCalendar.canChi(l.year)}")

        // Dải tuần (T2 -> CN)
        val offset = if (dow == Calendar.SUNDAY) -6 else Calendar.MONDAY - dow
        val start = now.clone() as Calendar
        start.add(Calendar.DAY_OF_YEAR, offset)
        for (i in 0..6) {
            val c = start.clone() as Calendar
            c.add(Calendar.DAY_OF_YEAR, i)
            val cd = c.get(Calendar.DAY_OF_MONTH)
            val cm = c.get(Calendar.MONTH) + 1
            val cy = c.get(Calendar.YEAR)
            val cdow = c.get(Calendar.DAY_OF_WEEK)
            val isToday = cy == y && c.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR)
            val cl = LunarCalendar.convert(cd, cm, cy)
            val box = vid(ctx, "week_${i}_box")
            val wd = vid(ctx, "week_${i}_wd")
            val dn = vid(ctx, "week_${i}_dn")
            val ln = vid(ctx, "week_${i}_ln")
            rv.setTextViewText(wd, if (cdow == Calendar.SUNDAY) "CN" else "T$cdow")
            rv.setTextViewText(dn, cd.toString())
            rv.setTextViewText(ln, if (cl.day == 1) "1/${cl.month}" else cl.day.toString())
            rv.setInt(box, "setBackgroundResource", if (isToday) st.today else 0)
            if (isToday) {
                rv.setTextColor(wd, st.todayText)
                rv.setTextColor(dn, st.todayText)
                rv.setTextColor(ln, st.todaySub)
            } else {
                rv.setTextColor(wd, if (cdow == Calendar.SUNDAY) st.sunday else st.weekLabel)
                rv.setTextColor(dn, st.primary)
                rv.setTextColor(ln, st.tertiary)
            }
        }

        // Thời tiết
        val w = sp.getString("weather_json", null)?.let { Weather.parse(it) }
        val place = sp.getString("name", DEFAULT_NAME) ?: DEFAULT_NAME
        if (w != null) {
            rv.setImageViewResource(R.id.w_icon, Weather.icon(w.code))
            rv.setTextViewText(R.id.w_temp, "${w.temp}°")
            val drop = "💧${w.humidity}%"
            val cond = SpannableString("${Weather.describe(w.code)} • $drop")
            val from = cond.length - drop.length
            cond.setSpan(ForegroundColorSpan(st.accent), from, cond.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            rv.setTextViewText(R.id.w_cond, cond)
            rv.setTextViewText(R.id.w_loc, "📍 $place • ↑${w.dMax[0]}° ↓${w.dMin[0]}°")

            for (i in 0..2) {
                val c = now.clone() as Calendar
                c.add(Calendar.DAY_OF_YEAR, i)
                val cdow = c.get(Calendar.DAY_OF_WEEK)
                val label = if (i == 0) "H.NAY" else if (cdow == Calendar.SUNDAY) "CN" else "THỨ $cdow"
                rv.setTextViewText(vid(ctx, "fc_${i}_label"), label)
                rv.setImageViewResource(vid(ctx, "fc_${i}_icon"), Weather.icon(w.dCode[i]))
                rv.setTextViewText(vid(ctx, "fc_${i}_pop"), "💧${w.dPop[i]}%")
                rv.setTextViewText(vid(ctx, "fc_${i}_temp"), "${w.dMin[i]}°/${w.dMax[i]}°")
            }
        } else {
            rv.setTextViewText(R.id.w_temp, "--°")
            rv.setTextViewText(R.id.w_cond, "Đang tải thời tiết…")
            rv.setTextViewText(R.id.w_loc, "📍 $place")
            for (i in 0..2) {
                val c = now.clone() as Calendar
                c.add(Calendar.DAY_OF_YEAR, i)
                val cdow = c.get(Calendar.DAY_OF_WEEK)
                rv.setTextViewText(vid(ctx, "fc_${i}_label"), if (i == 0) "H.NAY" else if (cdow == Calendar.SUNDAY) "CN" else "THỨ $cdow")
                rv.setTextViewText(vid(ctx, "fc_${i}_pop"), "--")
                rv.setTextViewText(vid(ctx, "fc_${i}_temp"), "--°/--°")
            }
        }

        for (i in 0..2) {
            rv.setTextColor(vid(ctx, "fc_${i}_label"), st.secondary)
            rv.setTextColor(vid(ctx, "fc_${i}_pop"), st.accent)
            rv.setTextColor(vid(ctx, "fc_${i}_temp"), st.primary)
        }

        // Pin
        val bi = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (bi != null) {
            val level = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val temp = bi.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0
            val status = bi.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
            rv.setTextViewText(
                R.id.battery,
                String.format(Locale.US, "%s%d%% • %.1f°C", if (charging) "⚡" else "🔋", pct, temp)
            )
        }

        // Chạm vào widget để làm mới
        val pi = PendingIntent.getBroadcast(
            ctx, 0,
            Intent(ctx, LichWidgetProvider::class.java).setAction(ACTION_REFRESH),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        rv.setOnClickPendingIntent(R.id.root, pi)

        mgr.updateAppWidget(ids, rv)
    }
}
