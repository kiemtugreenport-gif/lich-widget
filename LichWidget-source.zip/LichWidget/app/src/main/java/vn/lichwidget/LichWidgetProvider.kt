package vn.lichwidget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent

class LichWidgetProvider : AppWidgetProvider() {

    override fun onReceive(context: Context, intent: Intent) {
        val a = intent.action
        val handled = a == AppWidgetManager.ACTION_APPWIDGET_UPDATE ||
            a == WidgetUpdater.ACTION_REFRESH ||
            a == Intent.ACTION_DATE_CHANGED ||
            a == Intent.ACTION_TIME_CHANGED ||
            a == Intent.ACTION_TIMEZONE_CHANGED
        if (handled) {
            val pending = goAsync()
            val app = context.applicationContext
            val force = a == WidgetUpdater.ACTION_REFRESH
            Thread {
                try {
                    WidgetUpdater.update(app, force)
                } catch (e: Throwable) {
                } finally {
                    pending.finish()
                }
            }.start()
        } else {
            super.onReceive(context, intent)
        }
    }
}
