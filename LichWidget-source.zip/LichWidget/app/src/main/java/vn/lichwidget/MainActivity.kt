package vn.lichwidget

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private var dark = false
    private var cBg = 0
    private var cCard = 0
    private var cPrimary = 0
    private var cSec = 0
    private var cSep = 0
    private var cPressed = 0
    private val cAccent = 0xFF007AFF.toInt()
    private lateinit var locStatus: TextView

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }

    private fun tv(s: String, sizeSp: Float, color: Int, family: String = "sans-serif", style: Int = Typeface.NORMAL): TextView =
        TextView(this).apply {
            text = s
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
            setTextColor(color)
            typeface = Typeface.create(family, style)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sp = getSharedPreferences(WidgetUpdater.PREFS, Context.MODE_PRIVATE)

        dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        cBg = if (dark) 0xFF000000.toInt() else 0xFFF2F2F7.toInt()
        cCard = if (dark) 0xFF1C1C1E.toInt() else 0xFFFFFFFF.toInt()
        cPrimary = if (dark) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
        cSec = if (dark) 0xFF8E8E93.toInt() else 0xFF8A8A8E.toInt()
        cSep = if (dark) Color.argb(153, 84, 84, 88) else Color.argb(77, 60, 60, 67)
        cPressed = if (dark) 0xFF2C2C2E.toInt() else 0xFFE5E5EA.toInt()

        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        if (!dark) {
            var flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            window.decorView.systemUiVisibility = flags
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(40))
        }

        // Tiêu đề lớn
        root.addView(tv("Lịch Âm", 34f, cPrimary, "sans-serif", Typeface.BOLD))
        root.addView(
            tv("Giờ, lịch âm và thời tiết ngay trên màn hình chính", 15f, cSec),
            LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(2) }
        )

        // ---- Kiểu giao diện ----
        root.addView(header("Kiểu giao diện"))
        val hs = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipToPadding = false
            setPadding(dp(20), 0, dp(20), 0)
        }
        val rowL = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        hs.addView(rowL)
        root.addView(hs, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            leftMargin = -dp(20)
            rightMargin = -dp(20)
        })

        val wrappers = ArrayList<LinearLayout>()
        val labels = ArrayList<TextView>()

        fun applySelection(key: String) {
            Styles.all.forEachIndexed { i, s ->
                val sel = s.key == key
                wrappers[i].background = GradientDrawable().apply {
                    setColor(Color.TRANSPARENT)
                    cornerRadius = dp(22).toFloat()
                    setStroke(dp(3), if (sel) cAccent else Color.TRANSPARENT)
                }
                labels[i].setTextColor(if (sel) cAccent else cSec)
                labels[i].typeface = Typeface.create("sans-serif-medium", if (sel) Typeface.BOLD else Typeface.NORMAL)
            }
        }

        fun select(key: String) {
            sp.edit().putString("style", key).apply()
            applySelection(key)
            refreshWidgets()
        }

        Styles.all.forEach { st ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
            }
            val wrap = LinearLayout(this).apply { setPadding(dp(3), dp(3), dp(3), dp(3)) }
            wrap.addView(preview(st), LinearLayout.LayoutParams(dp(150), dp(120)))
            val label = tv(st.label, 13f, cSec, "sans-serif-medium").apply { gravity = Gravity.CENTER }
            item.addView(wrap)
            item.addView(label, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(6) })
            item.setOnClickListener { select(st.key) }
            wrappers.add(wrap)
            labels.add(label)
            rowL.addView(item, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(10) })
        }
        applySelection(Styles.get(sp.getString("style", "glass")).key)

        // ---- Thiết lập ----
        root.addView(header("Thiết lập"))
        locStatus = tv("", 15f, cSec)
        val settings = card()
        settings.addView(row("📍", 0xFF34C759.toInt(), "Vị trí", "Lấy thời tiết đúng nơi bạn ở", locStatus) { requestLocation() })
        settings.addView(divider())
        settings.addView(row("🔋", 0xFFFF9500.toInt(), "Pin", "Tắt tối ưu pin để widget luôn cập nhật", null) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        settings.addView(divider())
        settings.addView(row("🔄", 0xFF007AFF.toInt(), "Làm mới widget", "Cập nhật giờ và thời tiết ngay", null) {
            refreshWidgets()
            Toast.makeText(this, "Đã làm mới", Toast.LENGTH_SHORT).show()
        })
        root.addView(settings)

        // ---- Hướng dẫn ----
        root.addView(header("Thêm widget"))
        val guide = card()
        val steps = tv(
            "1   Nhấn giữ vào chỗ trống trên màn hình chính\n" +
                "2   Chọn Widget\n" +
                "3   Kéo \"Lịch Âm - Thời tiết\" ra màn hình",
            15f, cPrimary
        ).apply {
            setLineSpacing(0f, 1.35f)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        guide.addView(steps)
        root.addView(guide)

        root.addView(
            tv(
                "Ở mục Vị trí, hãy chọn \"Luôn cho phép\" để widget tự cập nhật khi bạn di chuyển. " +
                    "Chạm vào widget bất kỳ lúc nào để làm mới. Kiểu giao diện áp dụng cho mọi widget đang có.",
                13f, cSec
            ).apply { setPadding(dp(16), dp(10), dp(16), 0) }
        )

        setContentView(ScrollView(this).apply {
            setBackgroundColor(cBg)
            isVerticalScrollBarEnabled = false
            addView(root)
        })
    }

    // ---------- Thành phần giao diện ----------

    private fun header(s: String): TextView =
        tv(s.uppercase(), 13f, cSec, "sans-serif").apply {
            setPadding(dp(16), dp(26), dp(16), dp(8))
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(cCard, 14)
        clipToOutline = true
    }

    private fun divider(): View = View(this).apply {
        setBackgroundColor(cSep)
        layoutParams = LinearLayout.LayoutParams(MATCH, 1).apply { leftMargin = dp(60) }
    }

    private fun row(emoji: String, iconColor: Int, title: String, sub: String, trailing: TextView?, onClick: () -> Unit): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(14), dp(12))
            isClickable = true
            background = StateListDrawable().apply {
                addState(intArrayOf(android.R.attr.state_pressed), ColorDrawable(cPressed))
                addState(intArrayOf(), ColorDrawable(Color.TRANSPARENT))
            }
            setOnClickListener { onClick() }
        }
        val icon = TextView(this).apply {
            text = emoji
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            background = rounded(iconColor, 8)
        }
        r.addView(icon, LinearLayout.LayoutParams(dp(30), dp(30)))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(tv(title, 16f, cPrimary))
        col.addView(tv(sub, 13f, cSec), LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(1) })
        r.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(14) })

        if (trailing != null) {
            r.addView(trailing, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(8) })
        }
        r.addView(
            tv("›", 24f, cSec),
            LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(8) }
        )
        return r
    }

    /** Hình thu nhỏ của từng kiểu widget, đặt trên nền phong cảnh để thấy độ trong suốt. */
    private fun preview(st: WStyle): View {
        val frame = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF7DB7E3.toInt(), 0xFFBFDDF0.toInt(), 0xFF8DB35A.toInt(), 0xFF5E8F3B.toInt())
            ).apply { cornerRadius = dp(18).toFloat() }
            clipToOutline = true
        }
        val pv = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (st.rootBg != 0) pv.setBackgroundResource(st.rootBg)

        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (st.bodyBg != 0) body.setBackgroundResource(st.bodyBg)
        body.setPadding(dp(10), dp(8), dp(10), dp(8))

        body.addView(tv("15:10", 26f, st.primary, "sans-serif-medium"))
        body.addView(tv("Thứ Ba, 24 Thg 11", 11f, st.secondary))

        val line = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val pill = tv("16/10 ÂL", 10f, Color.WHITE, "sans-serif-medium")
        pill.setBackgroundResource(st.pill)
        pill.setPadding(dp(8), dp(2), dp(8), dp(2))
        val today = tv("24", 11f, st.todayText, "sans-serif-medium")
        today.setBackgroundResource(st.today)
        today.gravity = Gravity.CENTER
        today.setPadding(dp(8), dp(3), dp(8), dp(3))
        line.addView(pill)
        line.addView(today, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(6) })
        body.addView(line, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(6) })
        pv.addView(body)

        if (st.edge) {
            val edge = ImageView(this).apply {
                setImageResource(R.drawable.paper_edge)
                scaleType = ImageView.ScaleType.FIT_XY
            }
            pv.addView(edge, LinearLayout.LayoutParams(MATCH, dp(12)))
        }

        frame.addView(pv, FrameLayout.LayoutParams(MATCH, WRAP).apply {
            setMargins(dp(10), dp(12), dp(10), 0)
        })
        return frame
    }

    // ---------- Quyền và làm mới ----------

    override fun onResume() {
        super.onResume()
        refreshWidgets()
        updateLocationStatus()
    }

    private fun hasForeground(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun hasBackground(): Boolean =
        Build.VERSION.SDK_INT < 29 ||
            checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun updateLocationStatus() {
        locStatus.text = when {
            !hasForeground() -> "Chưa bật"
            hasBackground() -> "Luôn luôn"
            else -> "Khi dùng app"
        }
    }

    private fun requestLocation() {
        if (hasForeground() && Build.VERSION.SDK_INT >= 29 && !hasBackground()) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 2)
        } else {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                1
            )
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
            if (Build.VERSION.SDK_INT >= 29 && !hasBackground()) {
                requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 2)
            }
        }
        updateLocationStatus()
        refreshWidgets()
    }

    private fun refreshWidgets() {
        sendBroadcast(Intent(this, LichWidgetProvider::class.java).setAction(WidgetUpdater.ACTION_REFRESH))
    }
}
