package vn.lichwidget

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()
        val sp = getSharedPreferences(WidgetUpdater.PREFS, Context.MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(Color.parseColor("#FBF8F2"))
        }

        fun text(s: String, size: Float, bold: Boolean = false): TextView = TextView(this).apply {
            text = s
            textSize = size
            setTextColor(Color.parseColor("#14161C"))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, (10 * d).toInt())
        }

        fun button(s: String, onClick: () -> Unit): Button = Button(this).apply {
            text = s
            isAllCaps = false
            setOnClickListener { onClick() }
        }

        root.addView(text("Lịch Âm - Thời tiết", 24f, true))
        root.addView(text("Widget giờ, lịch âm và thời tiết theo vị trí của bạn.", 15f))
        root.addView(text("Cách thêm widget: nhấn giữ vào màn hình chính → Widget → chọn \"Lịch Âm - Thời tiết\".", 15f))

        root.addView(text("\nKiểu giao diện", 18f, true))
        val group = RadioGroup(this)
        val current = Styles.get(sp.getString("style", "glass")).key
        Styles.all.forEachIndexed { i, s ->
            val rb = RadioButton(this).apply {
                id = 1000 + i
                text = s.label + "\n" + s.desc
                textSize = 15f
                setTextColor(Color.parseColor("#14161C"))
                setPadding((8 * d).toInt(), (10 * d).toInt(), 0, (10 * d).toInt())
            }
            group.addView(rb)
            if (s.key == current) rb.isChecked = true
        }
        group.setOnCheckedChangeListener { _, checkedId ->
            val s = Styles.all[checkedId - 1000]
            sp.edit().putString("style", s.key).apply()
            refreshWidgets()
        }
        root.addView(group)

        root.addView(text("\nThiết lập", 18f, true))
        root.addView(button("1. Cho phép vị trí (để lấy thời tiết đúng nơi bạn ở)") { requestLocation() })
        root.addView(button("2. Tắt tối ưu pin (để widget luôn cập nhật)") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        root.addView(button("3. Làm mới widget ngay") { refreshWidgets() })
        root.addView(text("\nMẹo: ở bước 1, nếu máy hỏi quyền vị trí nền, hãy chọn \"Luôn cho phép\" để widget tự cập nhật vị trí khi bạn di chuyển. Chạm vào widget bất kỳ lúc nào để làm mới. Kiểu giao diện áp dụng cho mọi widget đang có.", 13f))

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refreshWidgets()
    }

    private fun requestLocation() {
        requestPermissions(
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
            1
        )
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
            if (Build.VERSION.SDK_INT >= 29 &&
                checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 2)
            }
        }
        refreshWidgets()
    }

    private fun refreshWidgets() {
        sendBroadcast(Intent(this, LichWidgetProvider::class.java).setAction(WidgetUpdater.ACTION_REFRESH))
    }
}
