# Lịch Âm - Thời tiết (Android widget)

Widget màn hình chính: giờ, lịch âm (Bính Ngọ...), dải tuần, thời tiết hiện tại + dự báo 3 ngày, pin.
Thời tiết lấy từ Open-Meteo (miễn phí, không cần API key), vị trí tự lấy theo GPS/mạng.

## Build ra APK (không cần Android Studio)
1. Tạo repo mới trên GitHub, tải toàn bộ thư mục này lên (giữ nguyên thư mục `.github`).
2. Vào tab **Actions** -> workflow **Build APK** -> chờ chạy xong (~3-5 phút). Nếu chưa tự chạy, bấm **Run workflow**.
3. Mở lần chạy đó -> mục **Artifacts** -> tải `LichWidget-apk` (giải nén ra `app-debug.apk`).

## Cài và dùng
1. Chép APK vào điện thoại, mở lên, cho phép "Cài từ nguồn không xác định".
2. Mở app "Lịch Âm - Thời tiết" -> bấm nút 1 để cấp quyền vị trí (chọn "Luôn cho phép" nếu được hỏi), nút 2 để tắt tối ưu pin.
3. Nhấn giữ màn hình chính -> Widget -> "Lịch Âm - Thời tiết" -> kéo ra màn hình.
Chạm vào widget để làm mới thủ công.
